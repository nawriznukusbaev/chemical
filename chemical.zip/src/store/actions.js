import {INCREMENT,DECREMENT} from "../constants";
export  const INC=()=>{
    return {
        type:INCREMENT
            }
}

export const DEC=()=>{
    return {
        type:DECREMENT
    }
}
