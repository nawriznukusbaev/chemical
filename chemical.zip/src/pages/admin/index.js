import {Admin} from "./admin";
export default Admin;