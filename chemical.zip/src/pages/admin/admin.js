import Dashboard from "../../components/admin/Dashboard";

export const Admin = ()=>{
    return (<Dashboard/>);
}