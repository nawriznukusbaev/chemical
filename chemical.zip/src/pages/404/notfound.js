export const NotFound=()=>{
    return (
        <div className="container-xl flex justify-center items-center h-[500px]">
            <p className="text-6xl text-black font-bold ">404 not found</p>
        </div>
    )
}