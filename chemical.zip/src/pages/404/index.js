import {NotFound} from "./notfound";
export default NotFound;