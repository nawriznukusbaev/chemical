export const Footer=()=>{
    return (<>
        <div className="w-full h-[400px] bg-[#2196f3]">
        </div>
    </>)
}