import {UserPage} from "./userpage";
export default UserPage;