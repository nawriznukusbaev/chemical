import {AdminLayout} from "./admin-layout";
export default AdminLayout;